package com.asu.cse535.project;

public class Constant {
    public static final int ERROR_DIALOG_REQUEST = 9001;
    public static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 9002;
    public static final int PERMISSIONS_REQUEST_ENABLE_GPS = 9003;
    public static final String MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey";
    public static final String GOOGLE_MAPS_API_KEY = "AIzaSyD7F-k0FXxv93lB3fzMBWG6bqhP4f8572Q";
    public static final int REQUEST_CODE_CURRENT_LOCATION = 2;
    public static final String[] BLUE_LIGHT = {"police","hosital"};
}
